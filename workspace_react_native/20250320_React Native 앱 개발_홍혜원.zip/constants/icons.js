import icon_edit from '@/assets/icons/edit.png'
import icon_delete from '@/assets/icons/delete.png'
// @ = 최상위 폴더에서 찾기 시작함.

export const icon = {
  ICON_EDIT : icon_edit,
  ICON_DELETE : icon_delete
}