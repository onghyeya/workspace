
export const data = [
  {
    id : 1,
    text : '리액트 공부하기',
  },
  {
    id : 2,
    text : '이력서 작성하기',
  },
  {
    id : 3,
    text : '오늘 저녁엔 쉬기기',
  }
]