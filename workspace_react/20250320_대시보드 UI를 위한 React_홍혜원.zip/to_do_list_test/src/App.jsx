import './App.css'
import List from './components/LIst'

function App() {

  return (
    <>
      <List/>
    </>
  )
}

export default App
